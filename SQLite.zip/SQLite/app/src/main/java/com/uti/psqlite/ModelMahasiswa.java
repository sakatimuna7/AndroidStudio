package com.uti.psqlite;

public class ModelMahasiswa{
    //buat variable sesuaikan dengan field tb_mahasiswa
    String npm,nama,jurusan;

    // Setter
    public void setNpm(String npm) {
        this.npm = npm;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }
    // Getter
    public String getNpm() {
        return npm;
    }
    public String getNama() {
        return nama;
    }
    public String getJurusan() {
        return jurusan;
    }

}
