package com.uti.psqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class DBConfig extends SQLiteOpenHelper {
    //contanta
    public static final String db_name = "db_mahasiswa";
    public static final int db_ver = 1;

    public DBConfig(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, db_name, null, db_ver);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // buat variable
        String sql;
        // buat tb mahasiswa
        sql = "CREATE TABLE 'tb_mahasiswa' (" +
                "'npm' TEXT(8) NOT NULL," +
                "'nama' TEXT(100) NOT NULL," +
                "'jurusan' TEXT(2) NOT NULL," +
                "PRIMARY KEY('npm')" +
                ");";
        //eksekusi perintah
        db.execSQL(sql);

        // isi data
        sql = "INSERT INTO tb_mahasiswa VALUES('18312175','Hamdan','IF')";
        db.execSQL(sql);
        sql = "INSERT INTO tb_mahasiswa VALUES('0001111','Tachi','IF')";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
