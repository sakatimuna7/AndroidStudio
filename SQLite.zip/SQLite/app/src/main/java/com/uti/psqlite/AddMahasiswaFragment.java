package com.uti.psqlite;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AddMahasiswaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AddMahasiswaFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AddMahasiswaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AddMahasiswaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AddMahasiswaFragment newInstance(String param1, String param2) {
        AddMahasiswaFragment fragment = new AddMahasiswaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    // ++++++++++++++++    Deklarasi     ++++++++++++++

    // buat variable
    DBConfig config;
    SQLiteDatabase db;
    Cursor cursor;

    // ++++++++++++++++    Butter Knife     ++++++++++++++

    // Deklarasi Variable
    @BindView(R.id.edt_npm) TextInputEditText edt_npm;
    @BindView(R.id.edt_nama) TextInputEditText edt_nama;
    @BindView(R.id.cbo_jurusan) Spinner cbo_jurusan;

    // Deklarasi array spinnner jurusan
    String[] jurusan = {
            "Pilih Jurusan","IF","SI","TK","TI","TE","TS"
    };

    @OnClick(R.id.img_tampil) void tampil() {
        // pangggil fragment view mahasiswa
        getActivity().getSupportFragmentManager().beginTransaction().
                replace(R.id.frm_layout,new ViewMahasiswaFragment()).
                commit();
    }
    //method btn_batal
    @OnClick(R.id.btn_batal) void batal(){
        reset_field();
    }

    // method btn_simpan
    @OnClick(R.id.btn_simpan) void simpan(){

//        short_toast(cbo_jurusan.getSelectedItem().toString());
        long  x;
        x = cbo_jurusan.getSelectedItemId();

        // if component is not null
//        if (edt_npm.)
        if(edt_npm.getText().toString().isEmpty()||
                edt_nama.getText().toString().isEmpty()||
                cbo_jurusan.getSelectedItemId()==0){
            short_toast("Seluruh data wajib di isi");
        }
        else {
            // cek apokah sudah pernah tersimpan atau belum
            db = config.getReadableDatabase();
            cursor = db.rawQuery("SELECT npm FROM tb_mahasiswa WHERE npm='"+ edt_npm.getText().toString() +"'",null);
            cursor.moveToFirst();

            // jika npm di temukan
            if(cursor.getCount() != 0){
                short_toast("Data Mahasiswa Sudah Pernah Tersimpan !");
                edt_npm.setError("Data Mahasiswa Sudah Pernah Tersimpan !");
                edt_npm.requestFocus();
            }
            // jika npm tidak ditemukan
            else{
                // simpan data
                db = config.getWritableDatabase();
                db.execSQL("INSERT INTO tb_mahasiswa VALUES ('"+edt_npm.getText().toString()+"'," +
                        "'"+edt_nama.getText().toString()+"','"+cbo_jurusan.getSelectedItem()+"')");
                short_toast("data berhasil disimpan");
                reset_field();
            }
        }
    }

    // ++++++++++++++++  /Butter Knife     ++++++++++++++

    void  reset_field(){
        edt_npm.setText("");
        edt_nama.setText("");
        cbo_jurusan.setSelection(0);
        edt_npm.requestFocus();
    }
    void short_toast(String string){
        Toast.makeText(getActivity(),string,Toast.LENGTH_SHORT).show();
    }
    String get_text(TextInputEditText textInputEditText){
       return textInputEditText.getText().toString();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // Ubah Judul / Title
        getActivity().setTitle("Tambah Data Mahasiswa");

        //Deklarasi VAriable View

        View view = inflater.
                inflate(R.layout.fragment_add_mahasiswa, container, false);
        ButterKnife.bind(this,view);

        // ++++++++++++++++    Inisialisai     ++++++++++++++

        // Input Array  ke dalam spinner
        ArrayAdapter arrayAdapter = new ArrayAdapter(
                getActivity(), android.R.layout.simple_spinner_dropdown_item,
                jurusan);

        // inisialisasi variable config
        config = new DBConfig(getActivity(),DBConfig.db_name,null,DBConfig.db_ver);

        cbo_jurusan.setAdapter(arrayAdapter);


        return view;
    }

}