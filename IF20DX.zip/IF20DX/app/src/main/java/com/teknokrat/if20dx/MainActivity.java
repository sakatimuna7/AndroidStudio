package com.teknokrat.if20dx;

import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.security.MessageDigest;

public class MainActivity extends AppCompatActivity {
    //    deklarasi variable komponen
    EditText edt_nilai1,edt_nilai2,edt_hasil;
    Button btn_hitung,btn_batal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    //  inisialisasi
        edt_nilai1 = findViewById(R.id.edt_nilai1);
        edt_nilai2 = findViewById(R.id.edt_nilai2);
        edt_hasil = findViewById(R.id.edt_hasil);
        btn_hitung = findViewById(R.id.btn_hitung);
        btn_batal = findViewById(R.id.btn_batal);
    btn_hitung.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
            int nilai1,nilai2;
            if(edt_nilai1.getText().toString().length() <=0 || edt_nilai2.getText().toString().length() <= 0){
                nilai1 = 0;
                nilai2 = 0;
            }else {
                nilai1 = Integer.valueOf(edt_nilai1.getText().toString());
                nilai2 = Integer.valueOf(edt_nilai2.getText().toString());
                int hasil = nilai1+nilai2;
                edt_hasil.setText(String.valueOf(hasil));
            }
        }
    });
    btn_batal.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            edt_hasil.setText("0");
            edt_nilai1.setText("");
            edt_nilai2.setText("");
            edt_nilai1.requestFocus();
        }
    });

    }

}