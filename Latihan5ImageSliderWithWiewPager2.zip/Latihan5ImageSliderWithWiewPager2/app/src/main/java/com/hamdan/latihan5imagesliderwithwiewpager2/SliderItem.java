package com.hamdan.latihan5imagesliderwithwiewpager2;

public class SliderItem {
    String img_banner;

    SliderItem(String img){
        this.img_banner = img;
    }

    public String getImg_banner() {
        return img_banner;
    }
}
