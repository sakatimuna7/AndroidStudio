package com.hamdan.latihan5imagesliderwithwiewpager2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;

public class SliderAdapter extends RecyclerView.Adapter<SliderAdapter.Holderku> {

    RecyleClick listener;
    LayoutInflater inflater;
    ArrayList<SliderItem> model;
    private ViewPager2 viewPager2;

    //Constuctor CustomAdapter
    SliderAdapter(ViewPager2 viewPager2, ArrayList<SliderItem> arrayList){
        this.viewPager2=viewPager2;
        this.model=arrayList;
    }

    @NonNull
    @Override
    public Holderku onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holderku(
                inflater.from(parent.getContext()).inflate(
                        R.layout.banner_item,parent,false
                )
        );
    }

    @Override
    public void onBindViewHolder(@NonNull Holderku holder, int position) {
        holder.setImage(holder,model.get(position).getImg_banner());
//        if(position == model.size() -2){
//            viewPager2.post(runnable);
//        }
    }

    @Override
    public int getItemCount() {
        return model.size();
    }


    // Custom Interface

    interface RecyleClick{
        void onClickItem(View view, int position);
    }

    void setClickListener(RecyleClick recyleClick){
        this.listener = recyleClick;
    }

    public class Holderku extends RecyclerView.ViewHolder{

        RoundedImageView img_banner;

        public Holderku(@NonNull View itemView) {
            super(itemView);
            img_banner = itemView.findViewById(R.id.imageSlider);

            itemView.setTag(itemView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null)listener.onClickItem(view,getAdapterPosition());
                }
            });
        }
        void setImage(@NonNull Holderku holder, String sliderItem){
            Glide.with(viewPager2)
                    .load(sliderItem)
                    .placeholder(R.drawable.img_gry)
                    .into(holder.img_banner);
        }
    }

//    private Runnable runnable = new Runnable() {
//        @Override
//        public void run() {
//            model.addAll(model);
//            notifyDataSetChanged();
//        }
//    };
}
