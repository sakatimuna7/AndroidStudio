package com.hamdan.latihan3;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    //Deklarasi
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Inisialisasi
        setContentView(R.layout.activity_main);
        bottomNavigationView = findViewById(R.id.bottomnavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId()==R.id.item_beranda){
                    load_fragment(new F_Beranda());
                    return true;
                }
                if(menuItem.getItemId()==R.id.item_feed){
                    load_fragment(new F_Feed());
                    return true;
                }
                if(menuItem.getItemId()==R.id.item_payment){
                    load_fragment(new F_Payment());
                    return true;
                }
                if(menuItem.getItemId()==R.id.item_user){
                    load_fragment(new F_User());
                    return true;
                }
                return false;
            }
        });
        load_fragment(new F_Beranda());
    }

    boolean load_fragment(Fragment fragment){
        if (fragment!=null){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.framelayout_content,fragment)
                    .commit();
            return true;
        }
        return false;
    }
}