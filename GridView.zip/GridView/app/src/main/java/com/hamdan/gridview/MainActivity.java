package com.hamdan.gridview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recycleItem;
    ArrayList<ObjekItem> listItemA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Load Data
        add_data_item();

        recycleItem = findViewById(R.id.recyclerview);
        CustomAdapterItem customAdapter = new CustomAdapterItem(getApplicationContext(), listItemA);

        recycleItem.setLayoutManager(new GridLayoutManager(this,2));
        recycleItem.setAdapter(customAdapter);

        customAdapter.setClickListener(new CustomAdapterItem.RecyleClick() {
            @Override
            public void onClickItem(View view, int position) {
                Toast.makeText(getApplicationContext(), listItemA.get(position).getTxt_judul(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void add_data_item(){
        listItemA = new ArrayList<>();
        listItemA.add(new ObjekItem("https://asset.kompas.com/crops/3kS9xmhBJh4b6y49vX7sR1O0e7I=/55x37:500x334/750x500/data/photo/2020/11/03/5fa10556e0357.jpg"
        ,"Meja Belajar Anak Kayu","120000","10","1","15"));
        listItemA.add(new ObjekItem("https://cdn.discordapp.com/attachments/954386665688940625/960383008312008724/default_img.jpg"
                ,"Meja Kantor Model Siku L","1200000","2","2","20"));
        listItemA.add(new ObjekItem("https://static.bmdstatic.com/pk/product/large/60408ebf92be5.jpg"
                ,"Kursi Kantor, Kursi Direktur, Sistem Pegas","1300000","0","0","0"));
        listItemA.add(new ObjekItem("https://cdn.kibrispdr.org/data/gambar-kursi-gaming-8.jpg"
                ,"Kusrsi Gameing Rexsus Red","120000","0","0","0"));
        for (int i=0;i<5;i++){

        }
    }
}

