package com.hamdan.gridview.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import com.hamdan.gridview.Adapter.FragmentDeskpripsi;
import com.hamdan.gridview.Adapter.SliderImageAdapter;
import com.hamdan.gridview.R;
import com.hamdan.gridview.objek.SliderImageItem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class DetailProduk extends AppCompatActivity {

    MaterialCardView cardView;
    ImageButton showButton;
    ViewPager2 imageSlider;
    LinearLayout hiddenLayout;
    CardView cardView_discount;
    BottomSheetDialog bottomSheetDialog;
    TextView txvJudul,txvReting,txvPrice,txvPriceDiscount,txvDiscount,txvDeskripsi;
    ArrayList<SliderImageItem> imagItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_produk);

        getImageItem();

        cardView = findViewById(R.id.material_card_view);
        //image slider
        imageSlider = findViewById(R.id.imageView);
        imageSlider.setAdapter(new SliderImageAdapter(imageSlider,imagItems));

        //Transformasin
        imageSlider.setClipToPadding(false);
        imageSlider.setClipChildren(false);
        imageSlider.setOffscreenPageLimit(3);
        imageSlider.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);

        //expandable deskripsi
        showButton = findViewById(R.id.img_button);
        showButton.setOnClickListener(v -> {
            FragmentDeskpripsi fragmentDeskpripsi = new FragmentDeskpripsi();
            fragmentDeskpripsi.show(getSupportFragmentManager(), fragmentDeskpripsi.getTag());
        });

        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(25));
        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.85f + r * 0.15f);

            }
        });
        imageSlider.setPageTransformer(compositePageTransformer);

        txvJudul = findViewById(R.id.txvJudul);
        txvPrice = findViewById(R.id.txvPrice);
        txvPriceDiscount = findViewById(R.id.txvPriceDiscount);
        txvDiscount = findViewById(R.id.txvDiscount);
        //cardview_discount
        cardView_discount = findViewById(R.id.cViewDiscount);



        //Ambil data dan rubah data
        int position = getIntent().getIntExtra("p",0);

        // ubah data
        txvJudul.setText(getIntent().getStringExtra("judul"));
        int price = Integer.parseInt(getIntent().getStringExtra("price"));
        txvPrice.setText(formatRupiah(price));
        int dis = Integer.parseInt(getIntent().getStringExtra("discount"));
        txvDiscount.setText(getIntent().getStringExtra("discount")+"%");
//        txvDeskripsi.setText(getIntent().getStringExtra("deskripsi"));
        if (dis == 0) {
            // membuat label diskon hilang
            cardView_discount.setVisibility(View.GONE);
        }
        if (dis > 0) {
            // membuat coretan pada harga discount
            txvPrice.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            txvPrice.setTextSize(12);
            txvPriceDiscount.setVisibility(View.VISIBLE);
            int discount = getDiscount(price,dis);
            txvPriceDiscount.setText(formatRupiah(discount));
        }

//        Expandable Deskripsi
//        showButton.setOnClickListener(view -> {
//            if(hiddenLayout.getVisibility() == view.VISIBLE){
//                TransitionManager.beginDelayedTransition(cardView,new AutoTransition());
//                hiddenLayout.setVisibility(view.GONE);
//                showButton.setImageResource(R.drawable.ic_baseline_keyboard_arrow_down_24);
//            }
//            else {
//                TransitionManager.beginDelayedTransition(cardView,new AutoTransition());
//                hiddenLayout.setVisibility(view.VISIBLE);
//                showButton.setImageResource(R.drawable.ic_baseline_keyboard_arrow_up_24);
//            }
//        });
    }
    private void getImageItem(){
        imagItems = new ArrayList<>();
        imagItems.add(new SliderImageItem(getIntent().getStringExtra("image")));
        imagItems.add(new SliderImageItem(getIntent().getStringExtra("d")));
    }
    private String formatRupiah(int uang){
        Locale localeId = new Locale("id","ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeId);

        String rupiah = formatRupiah.format(uang);

        return rupiah;
    }

    private int getDiscount(int price, int discount){
        int p = price-((discount*price)/100);
        return p;
    }
}