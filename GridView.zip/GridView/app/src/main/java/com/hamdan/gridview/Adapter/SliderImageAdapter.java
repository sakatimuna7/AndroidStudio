package com.hamdan.gridview.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.hamdan.gridview.R;
import com.hamdan.gridview.objek.SliderImageItem;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;

public class SliderImageAdapter extends RecyclerView.Adapter<SliderImageAdapter.Holderku> {

    RecyleClick listener;
    LayoutInflater inflater;
    ArrayList<SliderImageItem> model;
    private ViewPager2 viewPager2;

    //Constuctor CustomAdapter
    public SliderImageAdapter(ViewPager2 viewPager2, ArrayList<SliderImageItem> arrayList){
        this.viewPager2=viewPager2;
        this.model=arrayList;
    }

    @NonNull
    @Override
    public Holderku onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holderku(
                inflater.from(parent.getContext()).inflate(
                        R.layout.image_slider_item,parent,false
                )
        );
    }

    @Override
    public void onBindViewHolder(@NonNull Holderku holder, int position) {
        holder.setImage(holder,model.get(position).getImgItem());
//        if(position == model.size() -2){
//            viewPager2.post(runnable);
//        }
    }

    @Override
    public int getItemCount() {
        return model.size();
    }


    // Custom Interface

    interface RecyleClick{
        void onClickItem(View view, int position);
    }

    void setClickListener(RecyleClick recyleClick){
        this.listener = recyleClick;
    }

    public class Holderku extends RecyclerView.ViewHolder{

        RoundedImageView img_banner;

        public Holderku(@NonNull View itemView) {
            super(itemView);
            img_banner = itemView.findViewById(R.id.imageSlider);

            itemView.setTag(itemView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null)listener.onClickItem(view,getAdapterPosition());
                }
            });
        }
        void setImage(@NonNull Holderku holder, String sliderItem){
            Glide.with(viewPager2)
                    .load(sliderItem)
                    .placeholder(R.drawable.img_gry)
                    .into(holder.img_banner);
        }
    }

//    private Runnable runnable = new Runnable() {
//        @Override
//        public void run() {
//            model.addAll(model);
//            notifyDataSetChanged();
//        }
//    };
}
