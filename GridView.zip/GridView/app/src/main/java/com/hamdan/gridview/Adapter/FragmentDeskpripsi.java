package com.hamdan.gridview.Adapter;

import android.app.Dialog;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.hamdan.gridview.R;

public class FragmentDeskpripsi extends BottomSheetDialogFragment {

    public FragmentDeskpripsi() {

    }

    private AppBarLayout appBarLayout;
    private LinearLayout linearLayout;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
       final BottomSheetDialog dialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);
       View view = getActivity().getLayoutInflater().inflate(R.layout.fragment_deskripsi, null, false);
       dialog.setContentView(view);

       BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from((View) view.getParent());
       bottomSheetBehavior.setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);

       appBarLayout = view.findViewById(R.id.appBarLayout);
       linearLayout = view.findViewById(R.id.lyt_content);
       hideView(appBarLayout);

       bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
           @Override
           public void onStateChanged(View view, int i) {
               if (bottomSheetBehavior.STATE_EXPANDED == i) {
                   showView(appBarLayout, getActionBarSize());
                   hideView(linearLayout);
               }
               if (bottomSheetBehavior.STATE_COLLAPSED == i) {
                   hideView(appBarLayout);
                   showView(linearLayout, getActionBarSize());
               }
               if (bottomSheetBehavior.STATE_HIDDEN == i) {
                   dismiss();
               }
           }
           @Override
           public void onSlide(@NonNull View bottomSheet, float slideOffset) {

           }
       });

       view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               dismiss();
           }
       });

       return dialog;
    }

    private void hideView(View view) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = 0;
        view.setLayoutParams(params);
    }
    private void showView(View view, int size) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = size;
        view.setLayoutParams(params);
    }
    private int getActionBarSize() {
        final TypedArray styledAttributes = getContext().getTheme().obtainStyledAttributes(
                new int[] { android.R.attr.actionBarSize });
        return (int) styledAttributes.getDimension(0, 0);
    }
}
