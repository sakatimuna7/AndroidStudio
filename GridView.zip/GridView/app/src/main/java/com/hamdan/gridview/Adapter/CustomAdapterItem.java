package com.hamdan.gridview.Adapter;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import com.bumptech.glide.Glide;
import com.hamdan.gridview.objek.ObjekItem;
import com.hamdan.gridview.R;

public class CustomAdapterItem extends RecyclerView.Adapter<CustomAdapterItem.Holderku> {

    RecyleClick listener;
    LayoutInflater inflater;
    Context context;
    ArrayList<ObjekItem> model;

    public CustomAdapterItem(Context context, ArrayList<ObjekItem> arrayList) {
        this.context=context;
        this.model=arrayList;
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public Holderku onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.grid_item,null);
        return new Holderku(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holderku holder, int position) {
        holder.txt_judul.setText(model.get(position).getTxt_judul());
        holder.txt_price.setText(formatRupiah(Integer.parseInt(model.get(position).getTxt_price())));
        holder.txt_sale.setText(model.get(position).getTxt_sale()+" terjual");
        holder.txt_rank.setText("#"+model.get(position).getTxt_rank());
        holder.txt_discount.setText(model.get(position).getTxt_discount()+"%");
        Glide.with(context)
                .load(model.get(position).getImg_card())
                .placeholder(R.drawable.img_gry)
                .into(holder.img_card);
        if (Integer.parseInt(model.get(position).getTxt_discount()) == 0) {
            // membuat label diskon hilang
            holder.cardView_discount.setVisibility(View.GONE);
        }
        if (Integer.parseInt(model.get(position).getTxt_discount()) > 0) {
            // membuat coretan pada harga discount
            holder.txt_price.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            holder.txt_price.setTextSize(9);
            holder.txt_price_discount.setVisibility(View.VISIBLE);
            int d = getDiscount(Integer.parseInt(model.get(position).getTxt_price()),Integer.parseInt(model.get(position).getTxt_discount()));
            holder.txt_price_discount.setText(formatRupiah(d));
        }
        if(model.get(position).getTxt_rank() == "0") {
            holder.cardView_rank.setVisibility(View.GONE);
        }
    }

    private String formatRupiah(int uang){
        Locale localeId = new Locale("id","ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeId);

        String rupiah = formatRupiah.format(uang);

        return rupiah;
    }

    private int getDiscount(int price, int discount){
        int p = price-((discount*price)/100);
        return p;
    }

    @Override
    public int getItemCount() {
        return model.size();
    }

    //custom interface
    public interface RecyleClick{
        void onClickItem(View view, int position);
    }

    public void setClickListener(RecyleClick recyleClick){
        this.listener = recyleClick;
    }

    public class Holderku extends RecyclerView.ViewHolder {
        TextView txt_judul,txt_price,txt_sale,txt_rank,txt_discount;
        ImageView img_card;
        CardView cardView_discount,cardView_rank;

        TextView txt_price_discount;

        public Holderku(@NonNull View itemView) {
            super(itemView);
            txt_judul=itemView.findViewById(R.id.txt_judul);
            txt_price=itemView.findViewById(R.id.txvPrice);
            txt_sale=itemView.findViewById(R.id.txt_sale);
            txt_rank=itemView.findViewById(R.id.txt_rank);
            txt_discount=itemView.findViewById(R.id.txt_discount);
            img_card=itemView.findViewById(R.id.img_card);

            cardView_discount = itemView.findViewById(R.id.cardView_discount);
            cardView_rank = itemView.findViewById(R.id.cardView_rank);

            txt_price_discount = itemView.findViewById(R.id.txvPriceDiscount);


            itemView.setTag(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null)listener.onClickItem(view,getAdapterPosition());
                }
            });
        }
    }
}
