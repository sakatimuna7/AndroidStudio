package com.hamdan.gridview.objek;

public class ObjekItem {
    private String img_card="",txt_judul="",txt_price="",txt_sale="",txt_rank="",txt_discount="",deskripsi="";

    public ObjekItem(String img_card, String txt_judul, String txt_price, String txt_sale, String txt_rank, String txt_discount,String deskripsi) {
        this.img_card = img_card;
        this.txt_judul = txt_judul;
        this.txt_price = txt_price;
        this.txt_sale = txt_sale;
        this.txt_rank = txt_rank;
        this.txt_discount = txt_discount;
        this.deskripsi = deskripsi;
    }

    public String getImg_card() {
        return img_card;
    }

    public String getTxt_judul() {
        return txt_judul;
    }

    public String getTxt_price() {
        return txt_price;
    }

    public String getTxt_sale() {
        return txt_sale;
    }

    public String getTxt_rank() {
        return txt_rank;
    }

    public String getTxt_discount() {
        return txt_discount;
    }

    public String getDeskripsi() {
        return deskripsi;
    }
}
