package com.uti.pfragment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.uti.pfragment.fragment.Desain1Fragment;
import com.uti.pfragment.fragment.Desain2Fragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View view;
//        Button btn1,btn2,btn3;
//
//        view = findViewById(R.id.vw_layout);
//        btn1 = findViewById(R.id.bnt_menu1);
//        btn2 = findViewById(R.id.btn_menu2);
//        btn3 = findViewById(R.id.btn_menu3);

//        Tampilkan fragment
        getSupportFragmentManager().beginTransaction().replace(R.id.fl_layout,new Desain2Fragment()).commit();

    }
}