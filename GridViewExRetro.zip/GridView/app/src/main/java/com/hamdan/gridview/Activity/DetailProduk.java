package com.hamdan.gridview.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.card.MaterialCardView;
import com.hamdan.gridview.Adapter.FragmentDeskpripsi;
import com.hamdan.gridview.Adapter.SliderImageAdapter;
import com.hamdan.gridview.ApiData.CustomApi;
import com.hamdan.gridview.ApiData.GetData;
import com.hamdan.gridview.R;
import com.hamdan.gridview.objek.SliderImageItem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailProduk extends AppCompatActivity {

    MaterialCardView cardView;
    ImageButton showButton;
    ViewPager2 imageSlider;
    CardView cardView_discount;
    TextView txvJudul,txvPrice,txvPriceDiscount,txvDiscount;
    ProgressBar rbDetail;
    CollapsingToolbarLayout ctlJudul;
    ArrayList<SliderImageItem> imagItems;

    //shimmer
    ShimmerFrameLayout shimmerFrameLayout;
    NestedScrollView parent;

    private Bundle bundle = new Bundle();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_produk);

        FragmentDeskpripsi fragmentDeskpripsi = new FragmentDeskpripsi();
        fragmentDeskpripsi.setArguments(bundle);

        //shimmer
        shimmerFrameLayout = findViewById(R.id.shimmerDetail);
        shimmerFrameLayout.startShimmer();
//
        parent = findViewById(R.id.parent);

        cardView = findViewById(R.id.material_card_view);
        //expandable deskripsi
        showButton = findViewById(R.id.img_button);
        showButton.setOnClickListener(v -> {
            fragmentDeskpripsi.show(getSupportFragmentManager(), fragmentDeskpripsi.getTag());
        });
        rbDetail = findViewById(R.id.rbDetail);
        ctlJudul = findViewById(R.id.ctlJudul);
        txvJudul = findViewById(R.id.txvJudul);
        txvPrice = findViewById(R.id.txvPrice);
        txvPriceDiscount = findViewById(R.id.txvPriceDiscount);
        txvDiscount = findViewById(R.id.txvDiscount);
        //cardview_discount
        cardView_discount = findViewById(R.id.cViewDiscount);
        //get data from json by id
        get_data();

    }
    private  void customAdapterImage(){
        //image slider
        imageSlider = findViewById(R.id.imageView);
        imageSlider.setAdapter(new SliderImageAdapter(imageSlider,imagItems));

        //Transformasin
        imageSlider.setClipToPadding(false);
        imageSlider.setClipChildren(false);
        imageSlider.setOffscreenPageLimit(3);
        imageSlider.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);

        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(25));
        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.85f + r * 0.15f);

            }
        });
        imageSlider.setPageTransformer(compositePageTransformer);
    }
    private void getImageItem(String[] imageUrls){
        imagItems = new ArrayList<>();
        for (int i = 0; i < imageUrls.length; i++) {
            imagItems.add(new SliderImageItem(imageUrls[i]));
        }
        customAdapterImage();
    }
    private String formatRupiah(int uang){
        Locale localeId = new Locale("id","ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeId);

        String rupiah = formatRupiah.format(uang);

        return rupiah;
    }

    private int getDiscount(int price, int discount){
        int p = price-((discount*price)/100);
        return p;
    }
    private void get_data(){
        // connect to api
        CustomApi customApi = CustomApi.getInstance();
        Call<GetData> call = customApi.getDataById(getIntent().getStringExtra("id"));
        call.enqueue(new Callback<GetData>() {
            @Override
            public void onResponse(Call<GetData> call, Response<GetData> response) {
                // handle connection error
                if (!response.isSuccessful()) {
                    Toast.makeText(DetailProduk.this, "Code: " + response.code(), Toast.LENGTH_SHORT).show();
                }

                //using Asynctask
                //get data from json
                try {
                    //ambil data
                    GetData data = response.body();
                    //set data
                    rbDetail.setMax(5);
                    rbDetail.setProgress((int) Float.parseFloat(data.getRating()));
                    ctlJudul.setTitle(data.getNamaProduk());
                    txvJudul.setText(data.getNamaProduk());
                    int price = Integer.parseInt(data.getHarga());
                    txvPrice.setText(formatRupiah(price));
                    int dis = Integer.parseInt(data.getDiscount());
                    txvDiscount.setText(data.getDiscount()+"%");
                    if (dis == 0) {
                        // membuat label diskon hilang
                        cardView_discount.setVisibility(View.GONE);
                    }
                    if (dis > 0) {
                        // membuat coretan pada harga discount
                        txvPrice.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
                        txvPrice.setTextSize(12);
                        txvPriceDiscount.setVisibility(View.VISIBLE);
                        int discount = getDiscount(price,dis);
                        txvPriceDiscount.setText(formatRupiah(discount));
                    }
                    getImageItem(data.getImage());
                    //Bundle for send deskripsi to fragment
                    bundle.putString("deskripsi",data.getDeskripsi());
                    bundle.putString("judul",data.getNamaProduk());
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(DetailProduk.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                shimmerFrameLayout.stopShimmer();
                shimmerFrameLayout.setVisibility(View.GONE);
                parent.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(Call<GetData> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}