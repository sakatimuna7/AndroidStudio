package com.hamdan.gridview.ApiData;

import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CustomApi {
    private static final String BASE_URL = "https://62579cac74007111adf9a6dd.mockapi.io/";
    private static CustomApi instance;
    private Api api;

    private CustomApi() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        this.api = retrofit.create(Api.class);
    }

    public static CustomApi getInstance() {
        if (instance == null) {
            instance = new CustomApi();
        }
        return instance;
    }

    // get all data
    public Call<List<GetData>> getData() {
        return api.getData();
    }

    // get data by id
    public Call<GetData> getDataById(String id) {
        return api.getDataById(id);
    }

    // get data by keyword
    public Call<List<GetData>> getDataByKeyword(String keyword) {
        return api.getDataByKeyword(keyword);
    }
    //getDataByRating
    public Call<List<GetData>> getDataByRating(String rating, String sortBy, String order, String p, String l) {
        return api.getDataByRating(rating, sortBy, order, p, l);
    }
}
// End of code.
