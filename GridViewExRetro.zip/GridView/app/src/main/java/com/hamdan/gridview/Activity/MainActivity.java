package com.hamdan.gridview.Activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.hamdan.gridview.Adapter.CustomAdapterItem;
import com.hamdan.gridview.ApiData.Api;
import com.hamdan.gridview.ApiData.CustomApi;
import com.hamdan.gridview.ApiData.GetData;
import com.hamdan.gridview.objek.ObjekItem;
import com.hamdan.gridview.R;

import java.io.File;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    RecyclerView recycleItem;
    ArrayList<ObjekItem> listItemA;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Load Data from json
        get_data();


    }
    private void customAdapter(){
        recycleItem = findViewById(R.id.recyclerview);
        CustomAdapterItem customAdapter = new CustomAdapterItem(getApplicationContext(), listItemA);

        recycleItem.setLayoutManager(new GridLayoutManager(this,2));
        recycleItem.setAdapter(customAdapter);


        customAdapter.setClickListener(new CustomAdapterItem.RecyleClick() {
            @Override
            public void onClickItem(View view, int position) {
                Intent detail = new Intent(getApplicationContext(), DetailProduk.class);
                detail.putExtra("id",listItemA.get(position).getId());
                startActivity(detail);
            }
        });
    }
    private void get_data(){
        // custom api
        CustomApi customApi = CustomApi.getInstance();
        Call<List<GetData>> call = customApi.getData();
        call.enqueue(new Callback<List<GetData>>() {
            @Override
            public void onResponse(Call<List<GetData>> call, Response<List<GetData>> response) {
                if (response.isSuccessful()) {
                    listItemA = new ArrayList<>();
                    for (GetData getData : response.body()) {
                        listItemA.add(new ObjekItem(getData.getId(),getData.getImage(),getData.getNamaProduk(),
                                getData.getHarga(), getData.getTerjual(),"0",getData.getDiscount(),getData.getDeskripsi()));
                    }
                    customAdapter();
                }
            }

            @Override
            public void onFailure(Call<List<GetData>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Gagal", Toast.LENGTH_SHORT).show();
            }

        });
    }
}

