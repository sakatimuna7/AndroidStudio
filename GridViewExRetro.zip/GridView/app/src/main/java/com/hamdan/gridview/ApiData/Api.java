package com.hamdan.gridview.ApiData;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface Api {

    @GET("/produk")
    Call<List<GetData>> getData();

    //Get data retrofit by id
    @GET("/produk/{id}")
    Call<GetData> getDataById(@Path("id") String id);

    @GET("/produk?search={keyword}")
    Call<List<GetData>> getDataByKeyword(@Path("keyword") String keyword);

    ///produk?rating=5&sortBy=harga&order=desc&p=1&l=5
    @GET("/produk?rating={rating}&sortBy={sortBy}&order={order}&p={p}&l={l}")
    Call<List<GetData>> getDataByRating(@Path("rating") String rating, @Path("sortBy") String sortBy, @Path("order") String order, @Path("p") String p, @Path("l") String l);
}
