package com.hamdan.gridview.objek;

public class SliderImageItem {
    String imgItem;

    public SliderImageItem(String img){
        this.imgItem = img;
    }

    public String getImgItem() {
        return imgItem;
    }
}
