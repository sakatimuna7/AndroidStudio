package com.hamdan.latihan2;

import android.content.Context;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    //Deklarasi
    TabLayout tabLayout;
    ViewPager viewPager;
    // Deklarai Class Halaman sebagai adapter
    Halaman adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Inisialisasi Element
        setContentView(R.layout.activity_main);
        tabLayout = findViewById(R.id.tab);
        viewPager = findViewById(R.id.viewpager);
        adapter = new Halaman(getApplicationContext(),getSupportFragmentManager(),tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
class Halaman extends FragmentStatePagerAdapter{
    // deklarasi
    Context context;
    int jumlah_tab;

    //constructor Halaman
    Halaman(Context context, FragmentManager fragmentManager, int jumlah_tab){
        super(fragmentManager);
        this.context = context;
        this.jumlah_tab = jumlah_tab;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0: return new F_Satu();
            case 2: return new F_Dua();
            case 1: return new F_Tiga();
        }
        return null;
    }

    @Override
    public int getCount() {
        return jumlah_tab;
    }
}