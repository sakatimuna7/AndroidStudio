package com.hamdan.latihan4recyleview;

public class Objek {

    String nama="",alamat="";

    Objek(String nama, String alamat){
        this.nama= nama;
        this.alamat = alamat;
    }

    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }
}
