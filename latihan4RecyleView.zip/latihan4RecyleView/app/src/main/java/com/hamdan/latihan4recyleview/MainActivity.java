package com.hamdan.latihan4recyleview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Objek> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add_data();
        recyclerView=findViewById(R.id.recyclerview);
        CustomeAdapter customeAdapter = new CustomeAdapter(getApplicationContext(),list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        recyclerView.setAdapter(customeAdapter);
        customeAdapter.setClickListener(new CustomeAdapter.RecyleClick() {
            @Override
            public void onClickItem(View view, int position) {
                Toast.makeText(MainActivity.this,list.get(position).getNama(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void add_data(){
        list = new ArrayList<Objek>();
        list.add(new Objek("Hinata hhhhh hhhhhhh hhhhh","Jl.Durian lorem lorem lorem lorem lorem"));
        list.add(new Objek("Badrun bbbb bbbbbbbb bbbb","Jl.Delima lorem lorem lorem lorem lorem"));
        list.add(new Objek("Upin uuu uuuuuuu uuuuu","Jl.Pisang lorem lorem lorem lorem lorem"));
        list.add(new Objek("Denis dddddddddddddddd","Jl.Mangga lorem lorem lorem lorem lorem"));
        list.add(new Objek("Kinan kkkkkkkkkkkkkkk","Jl.Apple lorem lorem lorem lorem lorem"));
        for (int i=0; i<100; i++){
            list.add(new Objek("Hinata hhhhh hhhhhhh hhhhh","Jl.Durian lorem lorem lorem lorem lorem"));
            list.add(new Objek("Badrun bbbb bbbbbbbb bbbb","Jl.Delima lorem lorem lorem lorem lorem"));
            list.add(new Objek("Upin uuu uuuuuuu uuuuu","Jl.Pisang lorem lorem lorem lorem lorem"));
            list.add(new Objek("Denis dddddddddddddddd","Jl.Mangga lorem lorem lorem lorem lorem"));
            list.add(new Objek("Kinan kkkkkkkkkkkkkkk","Jl.Apple lorem lorem lorem lorem lorem"));
        };
    }

}


class CustomeAdapter extends RecyclerView.Adapter<CustomeAdapter.Holderku>{

    RecyleClick listener;
    LayoutInflater inflater;
    Context context;
    ArrayList<Objek> model;

    //Constructor
    CustomeAdapter(Context context, ArrayList<Objek> list){
        this.context=context;
        this.model=list;
        inflater=LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public Holderku onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item,null);
        return new Holderku(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holderku holder, int position) {
        holder.txv_nama.setText(model.get(position).getNama());
        holder.txv_alamat.setText(model.get(position).getAlamat());
    }

    @Override
    public int getItemCount() {
        return model.size();
    }

    // Custom Interface

    interface RecyleClick{
        void onClickItem(View view, int position);
    }

    void setClickListener(RecyleClick recyleClick){

        this.listener = recyleClick;
    }

    public class Holderku extends RecyclerView.ViewHolder{
        TextView txv_nama,txv_alamat;
        ImageView img;

        public Holderku(@NonNull View itemView) {
            super(itemView);
            txv_nama=itemView.findViewById(R.id.txv_nama);
            txv_alamat=itemView.findViewById(R.id.txv_alamat);
            img=itemView.findViewById(R.id.img);

            itemView.setTag(itemView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null)listener.onClickItem(view,getAdapterPosition());
                }
            });

        }
    }
}